#include<iostream>
using namespace std;
class time
{
private:
	int* hours;
	int*minutes;
	int*seconds;
public:
	//default constructor
	time()
	{
		hours = new int;
		minutes = new int;
		seconds = new int;
	}
	//copy constructor(deep copy)
	time(time &sample)
	{
		hours = new int;
		*hours = *(sample.hours);
		minutes = new int;
		*minutes = *(sample.minutes);
		seconds = new int;
		*seconds = *(sample.seconds);
	}
	//destructor
	~time()
	{
		delete hours;
		delete minutes;
		delete seconds;
	}
	
	//functions calling
	void set();
	void get();
	//operator overloading(==)
	bool time::operator ==(time &o)
	{
		if (*hours == *(o.hours) && *minutes == *(o.minutes) && *seconds == *(o.seconds))
		{
			return true;
		}
		else
			return false;
	}
	//operator overlaoding(>)
	bool time::operator>(time&o)
	{
		if (*hours >*(o.hours) && *minutes > *(o.minutes) && *seconds > *(o.seconds))
		{
			return true;
		}
		else
			return false;
	}
	//operator overlaoding(!=)
	bool time::operator !=(time&o)
	{
		if (*hours !=*(o.hours) && *minutes != *(o.minutes) && *seconds != *(o.seconds))
		{
			return true;
		}
		else
			return false;
	}
};
void time::set()
{
	cin >> *hours>>*minutes>>*seconds;
}
void time::get()
{
	cout << endl;
	cout <<*hours<<":"<<*minutes<<":"<<*seconds<<endl;
}


int main()
{
	time data1;
	cout << "Enter Time:" << endl;
	data1.set();
	cout << "Time is:" << endl;
	data1.get();
	cout << endl;
	time data2;
	cout << "Obj 2:" << endl;
	data2.set();
	//==operator overloading calling
	if (data1==data2)
	{
		cout << "Hence Equal" << endl;
	}
	else
	{
		cout << "Not Equal" << endl;
	}
	time data3;
	time data4;
	cout << "Enter obj3 Time:" << endl;
	data3.set();
	cout << "Enter obj4 time:" << endl;
	data4.set();
	//>operator overloading calling
	if (data3 > data4 )
	{
		cout << "Obj 1 is Greater that obj2" << endl;
	}
	else
		cout << "Not Greater"<< endl;
	time data5;
	time data6;
	cout << "Enter First Time:" << endl;
	data5.set();
	cout << "Enter second time:" << endl;
	data6.set();
	if (data5 != data6)
	{
		cout << "Data 1 is not equal to data2" << endl;
	}
	else
		cout << "Data 1 is equal to data 2" << endl;
	time data

}




